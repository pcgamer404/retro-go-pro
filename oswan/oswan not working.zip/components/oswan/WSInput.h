/*
$Date: 2009-10-30 05:26:46 +0100 (ven., 30 oct. 2009) $
$Rev: 71 $
*/

#ifndef WSINPUT_H_
#define WSINPUT_H_

#ifdef __cplusplus
extern "C" {
#endif

int WsInputGetState(int mode);

#ifdef __cplusplus
}
#endif

#endif // WSINPUT_H_
