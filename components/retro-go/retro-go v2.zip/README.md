# Description

Retro-Go's shared library (or framework) provides an easy way to port emulators to the ODROID-GO and the ESP32 in general.


# Supported Devices

| Name                                                          | Notes     |
|---------------------------------------------------------------|-----------|
| [brutzelboy](targets/brutzelboy/docs/README.md)               |           |
| [byteboi-rev1](targets/byteboi-rev1/docs/README.md)           |           |
| [crokpocket](targets/crokpocket/docs/README.md)               |           |
| [esp32-p4-devkit](targets/esp32-p4-devkit/docs/README.md)     |           |
| [esp32-s3-devkit](targets/esp32-s3-devkit/docs/README.md)     |           |
| [esplay-micro](targets/esplay-micro/docs/README.md)           |           |
| [fri3d-2024](targets/fri3d-2024/docs/README.md)               |           |
| [mrgc-g32](targets/mrgc-g32/docs/README.md)                   | Official  |
| [mrgc-gbm](targets/mrgc-gbm/docs/README.md)                   |           |
| [nullnano](targets/nullnano/docs/README.md)                   |           |
| [odroid-go](targets/odroid-go/docs/README.md)                 | Official  |
| [rachel-esp32](targets/rachel-esp32/docs/README.md)           |           |
| [redroid-go](targets/redroid-go/docs/README.md)               |           |
| [retro-esp32](targets/retro-esp32/docs/README.md)             |           |
| [retro-ruler](targets/retro-ruler/docs/README.md)             |           |
| [sdl2](targets/sdl2/docs/README.md)                           | Broken    |
| [t-deck-plus](targets/t-deck-plus/docs/README.md)             |           |
| [vmu-s3](targets/vmu-s3/docs/README.md)                       |           |


# Credits

## Retro-Go
- Alex Duchesne (ducalex)

## Go-Play
- crashoverride / hardkernel

## cJSON
- Dave Gamble (DaveGamble)

## lodepng
- Lode Vandevenne (lvandeve)

# License
[GPLv2](COPYING)

